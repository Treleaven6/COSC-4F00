//oe29dn

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(new File("src/input.txt"));

        int scenarios = scanner.nextInt();
        String result = "";

        for (int i = 0; i < scenarios; i++) {
            int n = scanner.nextInt();

            int k = n * (n - 1);

            int[][] value = new int[k][4];
            int[][] assist = new int[n][n];
            int[][] compass = new int[n][n];

            for (int j = 0; j < k; j++) {
                value[j][0] = scanner.nextInt();
                value[j][1] = scanner.nextInt();
                if (j % n == 0 || j % n == (n - 1)) continue;
                value[j][2] = scanner.nextInt();
            }

            for (int s = n - 3; s >= 0; s--) {
                for (int q = 0; q < n; q++) {
                    equate(value, n, s, q, assist, compass);
                }
            }
            int max = Integer.MIN_VALUE;
            int bestJ = 0;
            for (int j = 0; j < n; j++) {
                if (assist[0][j] > max) {
                    max = assist[0][j];
                    bestJ = j;
                }
            }
            int x = compass[0][bestJ];
            result += "Locations visited: " + "(" + "1," + (x + 1) + ") ";
            for (int j = 0; j < n - 1; j++) {
                x = compass[j][x];
                if (j == (n - 2)) result += " (" + (j + 2) + "," + (x + 1) + ")";
                else result += "(" + (j + 2) + "," + (x + 1) + ") ";
            }
            result += "\n";
            result += "Total earned: " + max;
            result += "\n\n";
        }
        Path path = Paths.get("src/output.txt");

        Files.write(path, result.getBytes());
    }

    private static void equate(int[][] value, int n, int s, int q, int[][] assist, int[][] compass) {
        int down;
        int left;
        int right;

        if (q == 0) {
            down = assist[s + 1][q] + value[s * n + q][0];
            right = assist[s + 1][q + 1] + value[s * n + q][1];
            if (down > right) {
                compass[s][q] = q;
                assist[s][q] = down;
            } else {
                compass[s][q] = q + 1;
                assist[s][q] = right;
            }
            return;
        }

        if (q == (n - 1)) {
            left = assist[s + 1][q - 1] + value[s * n + q][0];
            down = assist[s + 1][q] + value[s * n + q][1];
            if (down > left) {
                compass[s][q] = q;
                assist[s][q] = down;
            } else {
                compass[s][q] = q - 1;
                assist[s][q] = left;
            }
            return;
        }

        left = assist[s + 1][q - 1] + value[s * n + q][0];
        down = assist[s + 1][q] + value[s * n + q][1];
        right = assist[s + 1][q + 1] + value[s * n + q][2];

        if (down >= left && down >= right) {
            compass[s][q] = q;
            assist[s][q] = down;
        } else if (left >= down && left >= right) {
            compass[s][q] = q - 1;
            assist[s][q] = left;
        } else {
            compass[s][q] = q + 1;
            assist[s][q] = right;
        }
    }
}

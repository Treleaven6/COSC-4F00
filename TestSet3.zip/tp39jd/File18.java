//tp39jd

package project.chess;

import java.util.Vector;


public class ChessBoard {
    
	private Piece[][] board;
	private float score;
	private boolean whiteCastled;
	private boolean blackCastled;
	
	
	private boolean blackCheck;
	private boolean whiteCheck;
	private boolean blackMate;
	private boolean whiteMate;
	private boolean[] safeAreasBlack;
	private boolean[] knightAttackBlack;
	private boolean[] safeAreasWhite;
	private boolean[] knightAttackWhite;
	
	private Vector<Position> whiteEnemies;
	private Vector<Position> blackEnemies;
	
	private class Position {
		int x;
		int y;
		public Position(int xpos, int ypos) {
			this.x = xpos;
			this.y = ypos;
		} // constructor
	} // Position
	
	public ChessBoard(Piece[][] board, boolean wCastle, boolean bCastle) {
		whiteCastled = wCastle;
		blackCastled = bCastle;
		whiteMate = false;
		blackMate = false;
		
		this.board = new Piece[8][8];
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				this.board[i][j] = board[i][j].clone();
			}
		}
		
		score = Evaluator.evaluateBoard(this);
		safeAreasBlack = new boolean[8];
		knightAttackBlack = new boolean[8];
		safeAreasWhite = new boolean[8];
		knightAttackWhite = new boolean[8];
		whiteEnemies = new Vector<Position>();
		blackEnemies = new Vector<Position>();

		detectBlackCheck();
		detectWhiteCheck();
	} // constructor

	private ChessBoard(float value) {
		score = value;
	} // dummy constructor
	
	public static ChessBoard ChessBoardScoreFactory(float number) {
		return new ChessBoard(number);
	} // ChessBoardScoreFactory
	
	private void detectBlackCheck() {
		blackEnemies.clear();
		blackCheck = false;
		blackMate = false;
		
		for (int i = 0; i < 8; i++) {
			safeAreasBlack[i] = true;
			knightAttackBlack[i] = true;
		}
		
		/* _______________________________________ BLACK CHECK _______________________________________ */
		
		// find king
		int x_position = -1;
		int y_position = -1;
		
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				if (board[i][j].getPieceType() == PieceType.King 
						&& board[i][j].getPlayer() == Player.Black) {
					x_position = j;
					y_position = i;
					break;
				}
			}
		}
		
		if (x_position == -1) {
			return;
		}
		
		// check up
		for (int i = y_position-1; i > -1; i--) {
			if (i <= -1 || i >= 8) continue;
			if (board[i][x_position].getPlayer() == Player.Black) {
				break;
			} else if (board[i][x_position].getPieceType() == PieceType.Empty
						||  board[i][x_position].getPieceType() == PieceType.Bishop
							|| board[i][x_position].getPieceType() == PieceType.Knight
								|| board[i][x_position].getPieceType() == PieceType.Pawn)  {
				break;
			} else {
				blackEnemies.add(new Position(x_position, i));
				safeAreasBlack[1] = false;
				blackCheck = true;
			}
		}
		
		// check down
		for (int i = y_position+1; i < 8; i++) {
			if (i <= -1 || i >= 8) break;
			if (board[i][x_position].getPlayer() == Player.Black) {
				break;
			} else if (board[i][x_position].getPieceType() == PieceType.Empty
						|| board[i][x_position].getPieceType() == PieceType.Bishop
							|| board[i][x_position].getPieceType() == PieceType.Knight
								|| board[i][x_position].getPieceType() == PieceType.Pawn)  {
				break;
			} else {
				blackEnemies.add(new Position(x_position, i));
				safeAreasBlack[5] = false;
				blackCheck = true;
			}
		}
		
		// check left
		for (int j = x_position-1; j > -1; j--) {
			if (j <= -1 || j >= 8) continue;
			if (board[y_position][j].getPlayer() == Player.Black) {
				break;
			} else if (board[y_position][j].getPieceType() == PieceType.Empty
					|| board[y_position][j].getPieceType() == PieceType.Bishop
						|| board[y_position][j].getPieceType() == PieceType.Knight
							|| board[y_position][j].getPieceType() == PieceType.Pawn)  {
				break;
			} else {
				blackEnemies.add(new Position(j, y_position));
				safeAreasBlack[7] = false;
				blackCheck = true;
			}
		}
		
		// check right
		for (int j = x_position+1; j < 8; j++) {
			if (j <= -1 || j >= 8) continue;
			if (board[y_position][j].getPlayer() == Player.Black) {
				break;
			} else if (board[y_position][j].getPieceType() == PieceType.Empty
					|| board[y_position][j].getPieceType() == PieceType.Bishop
						|| board[y_position][j].getPieceType() == PieceType.Knight
							|| board[y_position][j].getPieceType() == PieceType.Pawn)  {
				break;
			} else {
				blackEnemies.add(new Position(j, y_position));
				safeAreasBlack[3] = false;
				blackCheck = true;
			}
		}
		int x = x_position;
		int y = y_position;
		while (x != 0 && y != 0) {
			x--;
			y--;
			if (board[y][x].getPlayer() == Player.Black) {
				break;
			} else if (board[y][x].getPieceType() == PieceType.Empty
					|| board[y][x].getPieceType() == PieceType.Knight
						||board[y][x].getPieceType() == PieceType.Rook
							|| board[y][x].getPieceType() == PieceType.Pawn
								|| board[y][x].getPieceType() == PieceType.King) {
				continue;
			} else {
				blackEnemies.add(new Position(x,y));
				safeAreasBlack[0] = false;
				blackCheck = true;
			}
		}
		x = x_position;
		y = y_position;
		while (x != 0 && y != 7) {
			x--;
			y++;
			if (board[y][x].getPlayer() == Player.Black) {
				break;
			} else if (board[y][x].getPieceType() == PieceType.Empty
					|| board[y][x].getPieceType() == PieceType.Knight
						||board[y][x].getPieceType() == PieceType.Rook
							|| board[y][x].getPieceType() == PieceType.Pawn
								|| board[y][x].getPieceType() == PieceType.King) {
				continue;
			} else {
				blackEnemies.add(new Position(x,y));
				safeAreasBlack[6] = false;
				blackCheck = true;
			}
		}
		x = x_position;
		y = y_position;
		while (x != 7 && y != 0) {
			x++;
			y--;
			if (board[y][x].getPlayer() == Player.Black) {
				break;
			} else if (board[y][x].getPieceType() == PieceType.Empty
					|| board[y][x].getPieceType() == PieceType.Knight
						||board[y][x].getPieceType() == PieceType.Rook
							|| board[y][x].getPieceType() == PieceType.Pawn
								|| board[y][x].getPieceType() == PieceType.King) {
				continue;
			} else {
				blackEnemies.add(new Position(x,y));
				safeAreasBlack[2] = false;
				blackCheck = true;
			}
		}
		x = x_position;
		y = y_position;
		while (x != 7 && y != 7) {
			x++;
			y++;
			if (board[y][x].getPlayer() == Player.Black) {
				break;
			} else if (board[y][x].getPieceType() == PieceType.Empty
					|| board[y][x].getPieceType() == PieceType.Knight
						||board[y][x].getPieceType() == PieceType.Rook
							|| board[y][x].getPieceType() == PieceType.Pawn
								|| board[y][x].getPieceType() == PieceType.King) {
				continue;
			} else {
				blackEnemies.add(new Position(x,y));
				safeAreasBlack[4] = false;
				blackCheck = true;
			}
		}
		
		// check for left pawn
		if (y_position < 7 && x_position > 0 
				&& board[y_position+1][x_position-1].getPlayer() == Player.White && board[y_position+1][x_position-1].getPieceType() == PieceType.Pawn) {
			blackEnemies.add(new Position(x_position-1, y_position+1));
			safeAreasBlack[6] = false;
			blackCheck = true;
		}
		
		// check for right pawn
		if (y_position < 7 && x_position < 7 
				&& board[y_position+1][x_position+1].getPlayer() == Player.White && board[y_position+1][x_position+1].getPieceType() == PieceType.Pawn) {
			blackEnemies.add(new Position(x_position+1, y_position+1));
			safeAreasBlack[4] = false;
			blackCheck = true;
		}
	}
}
//eb12yp

package Assign4;

import java.util.*;


public class Assign4 {
  private static int W;
  private static int H;
  private static int D;
  private static Queue<Vertex> vQueue;
  private static Queue<Edge> eQueue;
  private static int cost=0;
  
  public static void findPath(){
    while(vQueue.peek().getContent()!="S"){
      Vertex tmp=vQueue.remove();
      vQueue.add(tmp);
    }
    while(vQueue.peek()!=null&&vQueue.peek().getContent()!="E"&&vQueue.peek().getMark()!=true){
      Vertex u=vQueue.remove();
      Vertex v=vQueue.peek();
      Edge e= new Edge(u,v);
      while(e.getLabel()!=false){
        eQueue.add(e);
        cost++;
      }
    }
  }
  
  
  public static void main(String[] args) {
    
    Scanner in = new Scanner(System.in);
    System.out.print("Enter width: ");
    W = in.nextInt();
    System.out.print(W);
    System.out.print("Enter height: ");
    H = in.nextInt();
    System.out.print(H);
    System.out.print("Enter depth: ");
    D = in.nextInt();
    System.out.print(D);
    System.out.print("Enter maze below. Only rows of width "+W+" will be accepted.");
    for(int i=0;i<D;i++){
      for(int j=0;j<H;j++){
        for(int k=0;k<W;k++){
          String ac=in.next();
          if(ac!="X"){
            
            Vertex v= new Vertex(i,j,k,ac);
            vQueue.add(v);
          }
          System.out.print(ac);
        }System.out.print("/n");
      }System.out.print("/n");
    }
    System.out.print("/n");
    System.out.print("1. Solve suboptimally");
    System.out.print("2. Estimate optimal solution cost");
    System.out.print("3. Solve optimally");
    System.out.print("4. Enter new puzzle");
    System.out.print("5. Quit");
    findPath();
    Scanner prompt=new Scanner(System.in);
    int userin=prompt.nextInt();
    switch(userin){
      case 1: System.out.print("Not implemented. Use optimal instead");
      case 2: System.out.print("Estimated cost: "+cost);
      case 3: System.out.print("Optimal Path Cost: "+cost);
      System.out.print("Optimal Path: ");
      while(eQueue.peek()!=null){
        System.out.print(eQueue.peek().getDirection());
        eQueue.remove();
      }
      case 5: System.out.print("Goodbye");
    }
  }
}
//eb12yp

package Assign2;
import java.util.*;

public class AVLTree<E extends Comparable<E>> extends BinarySearchTree<E> {
  BinaryNode<E> myTree;
  public AVLTree(){
    
  }
  LinkedList<BinaryNode<E>> queue=new LinkedList<BinaryNode<E>>();
  LinkedList<BinaryNode<E>> prequeue=new LinkedList<BinaryNode<E>>();
  LinkedList<BinaryNode<E>> inqueue=new LinkedList<BinaryNode<E>>();
  
  
  public void add(E toInsert) {
    BinaryNode<E> ptr;
    if (myTree==null) {
      myTree=new BinaryNode<E>(toInsert);
    }
    else {
      ptr=myTree;
      while (true) {
        if (toInsert.compareTo(ptr.info)>0) { //Right branch
          if (ptr.right==null) { //Stick it here
            ptr.right=new BinaryNode<E>(toInsert);
            queue.add(ptr);
            break;
          }
          else ptr=ptr.right;
        }
        else { //Left branch
          if (ptr.left==null) { //Stick it here
            ptr.left=new BinaryNode<E>(toInsert);
            queue.add(ptr);
            break;
          }
          else ptr=ptr.left;
        }
        
      }
    }
  }
  
  
  public void inorder(AVLTree<E> aTree){
    if (aTree.getRoot()==null) {
      return;
    }
    BinaryNode<E> ptr=aTree.getRoot();
    while(ptr!=null){
      prequeue.add(ptr);
      ptr=ptr.left;
    }
    while(prequeue.size()!=0){
      ptr=prequeue.remove();
      System.out.print(ptr.info+" ");
      if(ptr.right!=null){
        ptr=ptr.right;
        while(ptr!=null){
          prequeue.add(ptr);
          ptr=ptr.left;
        }
      }
    }
  }
  public void inrder(AVLTree<E> aTree) {
    if(aTree.getRoot()==null) {
      return;
    }
    BinaryNode<E> ptr=aTree.getRoot();
    inqueue.add(ptr);
    while(inqueue.size()!=0){
      ptr=inqueue.remove();
      System.out.print(" "+ptr.info);
      if(ptr.right!=null){
        inqueue.add(ptr.right);
      }
      if(ptr.left!=null){
        inqueue.add(ptr.left);
      }
    }
  }  
}
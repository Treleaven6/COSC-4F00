//ft93mg

import java.util.Stack;

public class PartC {
    
        Stack<Integer> a,b,c;
        int n,ctr; 
        double limit;
        
    public PartC() {
        
        a = new Stack();
        b = new Stack();
        c = new Stack(); 
        ctr = 1;
    }

    private void runClass () {
        //n is the number of disks -1, for a 0 based representation.
        n = 4;
        limit = (Math.pow(2.0, ((double)(n+1))))-1;
        System.out.println("The limit is " + ((int)limit) + " moves.");
        for (int i=n; i>=0; i--) {
            a.push(i);
        }
        
        if (determine(n+1) == true) {
            //Set of steps for an even number of disks.
            //A-B Combinations
            for (int i=0; i<limit; i++) {
                
                if (a.empty() && b.empty()) break;
                
            if (b.empty() == true) {
                b.push(a.pop());
                System.out.println(ctr++ + ":  Disk " + b.peek() 
                                   + " from A to B");
            } else if (a.empty() == true) {
                a.push(b.pop());
                System.out.println(ctr++ + ":  Disk " + a.peek() 
                                   + " from B to A");
            } else if (minVal(a,b) == true) {
                a.push(b.pop());
                System.out.println(ctr++ + ":  Disk " + a.peek() 
                                   + " from B to A");
            } else {
                b.push(a.pop());
                System.out.println(ctr++ + ":  Disk " + b.peek() 
                                   + " from A to B");
            } //end of A-B combinations
            
            //A-C combinations
            if (c.empty() && a.empty()) break;
            
            if (c.empty() == true) {
                c.push(a.pop());
                System.out.println(ctr++ + ":  Disk " 
                                   + c.peek() + " from A to C");
            } else if (a.empty() == true) {
                a.push(c.pop());
                System.out.println(ctr++ + ":  Disk " + a.peek() 
                                   + " from C to A");
            } else if (minVal(a,c) == true){
                a.push(c.pop());
                System.out.println(ctr++ + ":  Disk " + a.peek() 
                                   + " from C to A");
            } else {
                c.push(a.pop());
                System.out.println(ctr++ + ":  Disk " + c.peek() 
                                   + " from A to C");
            } //end of A-C combination
            
            //C-B combinations
            if (b.empty() && c.empty()) break;
            
            if (b.empty() == true) {
                b.push(c.pop());
                System.out.println(ctr++ + ":  Disk " + b.peek() 
                                   + " from C to B");
            } else if (c.empty() == true) {
                c.push(b.pop());
                System.out.println(ctr++ + ":  Disk " + c.peek() 
                                   + " from B to C");
            } else if (minVal(c,b) == true) {
                c.push(b.pop());
                System.out.println(ctr++ + ":  Disk " + c.peek() 
                                   + " from B to C");
            } else {
                b.push(c.pop());
                System.out.println(ctr++ + ":  Disk " + b.peek() 
                                   + " from C to B");
            } //end of C-B combinations
          }
            
        } else {
            //Set of steps for an odd number of disks.
            //A-C combinations
            for (int i=0; i<limit; i++) {
                if (a.empty() && c.empty()) break;
                
            if (c.empty() == true) {
                c.push(a.pop());
                System.out.println(ctr++ + ":  Disk " + c.peek() 
                                   + " from A to C");
            } else if (a.empty() == true) {
                a.push(c.pop());
                System.out.println(ctr++ + ":  Disk " + a.peek() 
                                   + " from C to A");
            } else if (minVal(a,c) == true){
                a.push(c.pop());
                System.out.println(ctr++ + ":  Disk " + a.peek() 
                                   + " from C to A");
            } else {
                c.push(a.pop());
                System.out.println(ctr++ + ":  Disk " + c.peek() 
                                   + " from A to C");
            } //end of A-C combinations
            
            //A-B combinations
            if (b.empty() && a.empty()) break;
            
            if (b.empty() && !a.empty()) {
                b.push(a.pop());
                System.out.println(ctr++ + ":  Disk " + b.peek() 
                                   + " from A to B");
            } else if (a.empty() && !b.empty()) {
                a.push(b.pop());
                System.out.println(ctr++ + ":  Disk " + a.peek() 
                                   + " from B to A");
            } else if (minVal(a,b) == true) {
                a.push(b.pop());
                System.out.println(ctr++ + ":  Disk " + a.peek() 
                                   + " from B to A");
            } else {
                b.push(a.pop());
                System.out.println(ctr++ + ":  Disk " + b.peek() 
                                   + " from A to B");
            } //and of A-B combinations
            
            //C-B combinations
            if (b.empty() && c.empty()) break;
            
            if (b.empty() == true) {
                b.push(c.pop());
                System.out.println(ctr++ + ":  Disk " + b.peek() 
                                   + " from C to B");
            } else if (c.empty() == true) {
                c.push(b.pop());
                System.out.println(ctr++ + ":  Disk " + c.peek() 
                                   + " from B to C");
            } else if (minVal(c,b) == true) {
                c.push(b.pop());
                System.out.println(ctr++ + ":  Disk " + c.peek() 
                                   + " from B to C");
            } else {
                b.push(c.pop());
                System.out.println(ctr++ + ":  Disk " + b.peek() 
                                   + " from C to B");
            } //end of C-B combinations
          }
        }
    }
    
    private static boolean minVal(Stack<Integer> x, Stack<Integer> y) {
        if (x.peek() > y.peek()) {
            return true;
        } else {
            return false; 
        }
    } //minVal
    
    private static boolean determine(int n) {
        if (n%2 == 0) {
            return true;
        } else {
            return false;
        }
    } //determine 
    
    public static void main (String[] args) { PartC c = new PartC();
    c.runClass();
    } //main 
    
} //PartC
//bs20js

package Assign_1;


import BasicIO.*;                // for IO classes
import static BasicIO.Formats.*; // for field formats
import static java.lang.Math.*;  // for math constants and functions


/** This class ...
  *
  * @author Ji Wang
  * @version 1.0 (<date>)                                                        */

public class Life {
    
    private BasicForm form;
    private ASCIIDataFile worldFile;
    private char[][] world;
    // instance variables
    
    
    /** This constructor ...                                                     */
    
    public Life ( ) {
      int width;
      int height;
      int buttom;
      int generation;
      generation=0;
      worldFile=new ASCIIDataFile();
      form=new BasicForm("Next","Quit");
      width=worldFile.readInt();
      height=worldFile.readInt();
      setupForm(width,height);
      world=new char[height+2][width+2];
      loadWorld(width,height);
      displayWorld();
      for(;;){
        buttom=form.accept();
        if(buttom==1)break;
        else if(buttom==0){
        for(int i=0;i<height-1;i++){
          for(int j=0;j<width-1;j++){        
            nextGen(countNum(i,j),i,j);
          }
        }
        displayWorld();
        generation= generation+1;
        form.writeInt("generation",generation);
        }
        
      }
       form.close(); 
    } // constructor
    private void setupForm(int width,int height){
      form.addTextField("generation","Generation",8,10,10);
      form.setEditable("generation",false);
      form.addTextArea("world","World",height,width,10,30);
      form.setEditable("world",false);
    }
    private void loadWorld(int width,int height){
     
      for(;;){
        worldFile.nextLine();
        if(worldFile.isEOF())break;
        
        for(int i=1;i<=height;i++){
          for(int j=1;j<=width;j++){
            world[i][j]=worldFile.readC();
          }
          worldFile.nextLine();
        }
    }
    }
    private void displayWorld(){
        for(int i=1;i<world.length-1;i++){
          for(int j=1;j<=world[i].length-1;j++){
            form.writeC("world",world[i][j]);
          }
          form.newLine("world");
          
        }
        for(int k=0;k<world[world.length-1].length;k++){
          form.writeC("world",world[world.length-1][k]);
        }
        
     
    }
    
    private int countNum(int row,int col){
      int numLive=0;
          for(int k=row-1;k<=row+1&&k!=row;k++){
            for(int l=col-1;l<=col+1&&l!=col;l++){
              if (world[k][l]=='*'){numLive++;}
            }
          }
      
      
      return numLive;
    }
    private void nextGen(int numLive,int i,int j){
      if(world[i][j]!='*')
      {do{world[i][j]='*';}while(numLive==3);}
      else
      {switch(numLive){
        case 2:{}break;
        case 3:{}break;
        case 1:{world[i][j]=' ';}break;
        case 4:{world[i][j]=' ';}break;
        case 5:{world[i][j]=' ';}break;
        case 6:{world[i][j]=' ';}break;
        case 7:{world[i][j]=' ';}break;
        case 8:{world[i][j]=' ';}break;
    } // methods

      }
    }
    // For main classes only:
    public static void main ( String[] args ) { Life c = new Life(); };
    
    
} // Life

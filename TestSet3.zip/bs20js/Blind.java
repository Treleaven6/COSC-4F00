//bs20js

package assign1;

import java.util.*;
/**
 *
 * @author Thinkpad
 */
public class Blind {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        System.out.println("How many queens do you want to place?");
        int n=in.nextInt();
        char board[][]=new char[n][n];
        for(int i=0;i<n;i++){
            for(int j=0;j<n;j++){
                board[i][j]='*';
            }
        }
        solve(board,0);
        // TODO code application logic here
    }
    private static boolean isValid(char board[][],int row,int col){
        for(int i=0;i<row;i++){
            if(board[i][col]=='Q'){
                return false;
            }
        }//check if there is a queen on the same row
        for(int i=row,j=col; i>=0&&j>=0; i--,j--){
            if(board[i][j]=='Q'){
                return false;
            }
        }
        for(int i=row,j=col; i<board.length&&j<board.length; i++,j++){
            if(board[i][j]=='Q'){
                return false;
            }
        }//check diagonal(upperleft and bottomright)
        return true;
    }
    private static void solve(char board[][], int current)
    {
        if (current == board.length)
        {
            System.out.println("Solution");
            for (int i=0; i<current; i++)
            {
                for (int j=0; j<current; j++)
                    System.out.print(board[i][j] + "*");
                System.out.println();
            }//print out each solution
        }
        for (int j=0; j<board.length; j++)
        {
            if (isValid(board, current, j))
            {
                board[current][j] = 'Q';
                solve(board, current + 1);
                board[current][j] = '*';
            }
        }//recursively search for solutions
    }
}

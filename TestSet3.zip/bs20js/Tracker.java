//bs20js

package Assign_2;
import BasicIO.*;
import static BasicIO.Formats.*;

public class Tracker{
  private Node posted;
  private Node pending;
  private Node closed;
  private ASCIIDisplayer display;
  private BasicForm form;
  
  public Tracker(){
    int buttom;
    display=new ASCIIDisplayer();
    
    posted=null;
    pending=null;
    closed=null;
    
    for(;;){
      form=new BasicForm("Create","Assign","Resolve","List","Quit");
      setupForm();
      buttom=form.accept();
      loadTracker();
      if(buttom==4)break;
      switch(buttom){
        case 0:{
          form=new BasicForm();
          setupTicket();
          doCreate();
          break;
        }
        case 1:{
          form=new BasicForm();
          setupTicket();
          doAssign();
          break;
        }
        case 2:{
          form=new BasicForm();
          setupTicket();
          doResolve();
          break;
        }
        case 3:{
          doList();
          break;
        }
      }
      form.accept("OK");
    }
    form.close();
    display.close();
  }
  private void loadTracker(){
    int num=form.readInt("ticketNum");
  }
  private void doCreate(){
    Issue anissue;
    int pri=form.readInt("priority");
    String uname=form.readString("user");
    String idetail=form.readString("issueDetail");
    
  }
  private void doAssign(){
  }
  private void doResolve(){
  }
  private void doList(){
  }
  private void setupForm(){
    form.setTitle("Bug Tracker");
    form.addTextField("ticketNum","Ticket#",10,10,10);
  }
  private void setupTicket(){
    form.setTitle("Ticket");
    form.addTextField("ticketNum","Ticket#",5,10,10);
    form.addTextField("priority","Priority",2,10,35);
    form.addTextField("status","Status",6,100,35);
    form.addTextField("user","User",14,10,60);
    form.addTextArea("issueDetail","Issue",4,20,10,85);
    form.addTextField("technician","Technician",14,10,200);
    form.addTextArea("resolution","Resolution",4,20,10,225);
  }
  private void fillForm(Issue anIssue){
  }
                   

  public static void main(String[] args){Tracker r=new Tracker();};
}
  
//co05kb

package MachineLearning;

import java.util.Arrays;

public class Vector implements VectorInterface {

	private int number,a,b;
	private double[] VectorArrayD;
	private int[] VectorArrayI;
	Vector temp;
	double value;

	Vector() {
	}

	Vector(int size, double D) {
		VectorArrayD = new double[size];
		for (int i = 0; i < size; i++) {
			VectorArrayD[i] = D;
		}
	}

	Vector(double[] D) {
		number = D.length;
		VectorArrayD = new double[number];
		for (int i = 0; i < number; i++) {
			VectorArrayD[i] = D[i];
		}
	}

	Vector(int[] I) {
		number = I.length;
		VectorArrayI = new int[number];
		for (int i = 0; i < number; i++) {
			VectorArrayI[i] = I[i];
		}
	}

	@Override
	public Vector append(double[] doubleArray) {
		a = 0;
		b = 0;
		double[] VectorTempD = new double[this.getLength()+doubleArray.length];
		for (a = 0; a< this.getLength(); a++){
			VectorTempD[a] = this.getValue(a);
		}
		for (int j = a; b < doubleArray.length; j++){
			VectorTempD[j] = doubleArray[b];
			b++;
		}
		temp = new Vector(VectorTempD);
		return temp;
	}

	@Override
	public Vector append(int[] intArray) {
		a = 0;
		b = 0;
		int[] VectorTempI = new int[this.getLength()+intArray.length];
		for (a = 0; a< this.getLength(); a++){
			VectorTempI[a] = this.getValue(a).intValue();
		}
		for (int j = a; b < intArray.length; j++){
			VectorTempI[j] = intArray[b];
			b++;
		}
		temp = new Vector(VectorTempI);
		return temp;
	}

	@Override
	public Vector append(Vector V) {
		a = 0;
		b = 0;
		double[] VectorTempD = new double[this.getLength()+V.getLength()];
		for (a = 0; a< this.getLength(); a++){
			VectorTempD[a] = this.getValue(a);
		}
		for (int j = a; b < V.getLength(); j++){
			VectorTempD[j] = V.getValue(b);
			b++;
		}
		temp = new Vector(VectorTempD);
		return temp;
	}

	@Override
	public Vector append(double aDouble) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Vector clone() {
		temp = this;
		return temp;
	}

	@Override
	public Boolean equal(Vector V) {
		if (this.getLength() != V.getLength()) {
			return false;
		}
		for (int i = 0; i < this.getLength(); i++) {
			if (!this.getValue(i).equals(V.getValue(i))) {
				return false;
			}
		}
		return true;
	}

	@Override
	public int getLength() {
		int len = 0;
		if (this.VectorArrayI instanceof int[]) {
			len = VectorArrayI.length;
		} else if (this.VectorArrayD instanceof double[]) {
			len = VectorArrayD.length;
		}
		return len;
	}

	@Override
	public Double getValue(int i) {
		double val = 0;
		if (this.VectorArrayI instanceof int[]) {
			val = (double) this.VectorArrayI[i];
		} else if (this.VectorArrayD instanceof double[]) {
			val = this.VectorArrayD[i];
		}
		return val;
	}

	public Vector add(Vector V) {
		if (this.getLength() != V.getLength()) {
			System.out.println("The vector lengths do not match.");
		} else {
			if (this.VectorArrayI instanceof int[] && V.VectorArrayI instanceof int[]) {
				int[] VectorTempI = new int[this.getLength()];
				for (int i = 0; i < this.getLength(); i++) {
					VectorTempI[i] = (int) (this.getValue(i) + V.getValue(i));
				}
				temp = new Vector(VectorTempI);
			} else {
				double[] VectorTempD = new double[this.getLength()];
				for (int i = 0; i < this.getLength(); i++) {
					VectorTempD[i] = (this.getValue(i) + V.getValue(i));
				}
				temp = new Vector(VectorTempD);
			}
		}
		return temp;
	}

	public Vector add(double aDouble) {
		double[] VectorTempD = new double[this.getLength()];
		for (int i = 0; i < this.getLength(); i++) {
			VectorTempD[i] = (this.getValue(i) + aDouble);
		}
		temp = new Vector(VectorTempD);
		return temp;
	}

	public Vector sub(Vector V) {
		double[] VectorTempD = new double[this.getLength()];
		if (this.getLength() != V.getLength()) {
			System.out.println("The vector lengths do not match.");
		} else {
			for (int i = 0; i < this.getLength(); i++) {
				VectorTempD[i] = (this.getValue(i) - V.getValue(i));
			}
		}
		temp = new Vector(VectorTempD);
		return temp;

	}

	public Vector subV(int l, int r) {
		double[] VectorTempD = new double[r - l + 1];
		number = r - l;
		if (r <= this.getLength() && l >= 0) {
			for (int i = 0; i <= number; i++) {
				VectorTempD[i] = (this.getValue(l));
				l++;
			}
			temp = new Vector(VectorTempD);
		} else {
			System.out.println("Invalid input to get subvector.");
		}
		return temp;
	}

	@Override
	public Vector Mult(Vector V) {
		double[] VectorTempD = new double[this.getLength()];
		if (this.getLength() != V.getLength()) {
			System.out.println("The vector lengths do not match.");
		} else {
			for (int i = 0; i < this.getLength(); i++) {
				VectorTempD[i] = this.getValue(i) * V.getValue(i);
			}
			temp = new Vector(VectorTempD);
		}
		return temp;
	}

	@Override
	public Vector Mult(double aDouble) {
		double[] VectorTempD = new double[this.getLength()];
		for (int i = 0; i < this.getLength(); i++) {
			VectorTempD[i] = (this.getValue(i) * aDouble);
		}
		temp = new Vector(VectorTempD);
		return temp;
	}

	@Override
	public Vector Normalize() {
		value = 0;
		double[] VectorTempD = new double[this.getLength()];
		for (int i = 0; i < this.getLength(); i++) {
			value = value + (this.getValue(i) * this.getValue(i));
		}
		value = Math.sqrt(value);
		for (int i = 0; i < this.getLength(); i++) {
			VectorTempD[i] = this.getValue(i) / value;
		}
		temp = new Vector(VectorTempD);
		return temp;
	}

	@Override
	public Double EuclidianDistance(Vector V) {
		value = 0;
		double[] VectorTempD = new double[this.getLength()];
		if (this.getLength() != V.getLength()) {
			System.out.println("The vector lengths do not match.");
		} else {
			for (int i = 0; i < this.getLength(); i++) {
				value = value + (Math.pow(V.getValue(i) - this.getValue(i), 2));
			}
		}
		value = Math.sqrt(value);
		return value;
	}

}

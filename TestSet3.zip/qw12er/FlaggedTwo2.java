//qw12er

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Main2 {

    static final int INF = Integer.MAX_VALUE;

    public static void main(String[] args) throws IOException {
        String data = new String(Files.readAllBytes(Paths.get("src/question 2 input.txt")));
        String[] cases = data.split("\\n\\n");
        String result = "";
        for (String i : cases) {
            String[] spl = i.split("\n", 2);

            if (spl[0].isEmpty()) break;
            int M = Integer.valueOf(spl[0]);

            result += fourmat(M, spl[1]);
            result += "\n";
        }
        Path path = Paths.get("src/question 2 output.txt");

        Files.write(path, result.getBytes());
    }

    private static long priceOfLine(String[] arr, int i, int j, int M) {
        if (i == j) return 600;
        int numberOfSpaces = j - i;
        long sum = 0;
        long additionalCost = 0;
        long a = 0;
        long b = 0;
        for (int k = i; k <= j; k++) {
            sum += arr[k].length();
        }
        sum += numberOfSpaces;
        if (sum > M) return INF;
        additionalCost = M - sum;
        a = additionalCost / numberOfSpaces;
        b = additionalCost % numberOfSpaces;
        additionalCost = (numberOfSpaces - b) * a * a + b * (a + 1) * (a + 1);
        return additionalCost;
    }

    private static void costOfText(int M, String[] arr, long[] knownCost, int[] b, int index) {
        long bestCost = INF;
        int bestI = 0;
        if (index == arr.length) return;
        for (int i = index; i < arr.length; i++) {
            if (priceOfLine(arr, index, i, M) + knownCost[i + 1] < bestCost) {
                bestI = i;
                bestCost = priceOfLine(arr, index, i, M) + knownCost[i + 1];
            }
        }
        knownCost[index] = bestCost;
        b[index] = bestI + 1;
    }

    private static String addingSpace(String[] arr, int indicator1, int indicator2, int M, int currentIndex) {
        String result = "";
        if (indicator1 + 1 == indicator2) {
            for (int i = 1; i <= M - arr[currentIndex].length(); i++) result += " ";
            return result;
        }
        int numberOfSpaces = indicator2 - indicator1 - 1;
        int sum = 0;
        int additionalCost;
        int a;
        int b;
        for (int k = indicator1; k < indicator2; k++) {
            sum += arr[k].length();
        }
        sum += numberOfSpaces;
        additionalCost = M - sum;
        a = additionalCost / numberOfSpaces;
        b = additionalCost % numberOfSpaces;
        if (currentIndex - indicator1 < b) {
            for (int i = 1; i <= a + 2; i++)
                result += " ";
        } else {
            for (int i = 1; i <= a + 1; i++)
                result += " ";
        }
        return result;
    }

    private static String fourmat(int M, String s) {
        String result = "";
        String[] arr = s.replaceAll("\n", " ").split(" ");
        long[] knownCost = new long[arr.length + 1];
        int[] b = new int[arr.length + 1];
        for (int i = arr.length - 1; i >= 0; i--) {
            costOfText(M, arr, knownCost, b, i);
        }

        int indicator1 = 0;
        int indicator2 = b[0];

        for (int i = 0; i < arr.length; i++) {
            if (i + 1 == indicator2) {
                indicator1 = indicator2;
                indicator2 = b[i + 1];
                result += arr[i] + "\n";
                continue;
            }
            result += arr[i] + addingSpace(arr, indicator1, indicator2, M, i);
        }
        return result;
    }

}

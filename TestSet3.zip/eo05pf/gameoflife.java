//eo05pf

package GameOfLife;
import java.util.*;
import java.io.*;



public class LifeGame {
	public LifeGame () {
		Scanner console = new Scanner (System.in);
		System.out.println("Please enter your text file:");
		String filename = console.next();
		int [][] gameboard  = loadState(filename);
		System.out.println("This is the initial Game Board:");
		printboard (gameboard);
		System.out.println("Please enter the number of iterations:");
		int iterations = console.nextInt();
	}

	public void iterate (int [][] someArray, int number1, int number2) {
		int [][] newArray = null;
		for (int i = 0 ; i < someArray.length ; i ++) {
			for(int j = 0 ; j <  someArray[0].length; j++){
				if (someArray[number1][number2] == 0){
					if (countNeighbours (someArray, number1, number2) == 3 ){
						someArray[number1][number2] = newArray[number1][number2];
					}
				}
				
			}
			}
	}
	
	public int getCell (int [][] Array, int number1, int number2){
		return Array[number1][number2];
	}
	
	public int countNeighbours (int [][] someArray, int x, int y) {
		int counter = 0;
		if (getCell (someArray,x-1, y-1) == 1){
			counter++;
		}
		if (getCell (someArray, x-1,y)==1){
			counter++;
		}
		if (getCell (someArray, x-1, y+1)==1){
			counter++;
		}
		if (getCell (someArray,x,y+1)==1){
			counter++;
		}
		if (getCell (someArray, x+1,y+1)==1){
			counter++;
		}
		if (getCell (someArray,x+1,y)==1){
			counter++;
		}
		if(getCell (someArray, x+1,y-1)==1){
			counter++;
		}
		if(getCell (someArray, x, y-1)==1){
			counter++;
		}
		return counter;
	}
	
	public void printboard (int [][] someArray) {
		for (int i = 0 ; i < someArray.length ; i ++) {
			for(int j = 0 ; j <  someArray[0].length; j++){
				System.out.print (someArray [i][j]+ "\t");	
			}
			System.out.println();
			
		}
	}
	
	private int [][] loadState(String filename) {
		Scanner file = null;
		String line;
		String [] dimensions;
		String [] value;
		int [][] board = null;
		try {
			file=new Scanner(new File(filename)); //This lets you use Scanner as normal, except from a text file!
			//You'd do reads here. The try/catch lets you handle problems gracefully
			
			line = file.nextLine();
			dimensions = line.split("\t");
			board = new int [Integer.parseInt(dimensions[0])][Integer.parseInt(dimensions[1])];
			
			for (int row = 0 ; row < board.length; row++){
				
				line = file.nextLine();
				value = line.split("\t");
				
				
				for (int col = 0 ; col < board[0].length; col++){
					
					board [row][col] = Integer.parseInt(value[col]);
					
				}
			}
			
		}
		catch (Exception exn) {
			
		}
		file.close();
		
		return board;
	}
	
	public static void main (String args[]) {
		new LifeGame () ;
		}
	
	
}

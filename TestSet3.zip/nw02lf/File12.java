//nw02lf

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class lalala { //changing comment idk

    public static void main(String[] args) throws IOException {
        String result = "";
        Scanner scanner = new Scanner(new File("src/in.txt"));
		int z = 0;

        int numbaOfPlots = scanner.nextInt(); //bam

        for (int i = 0; i < numbaOfPlots; i++) {
            int n = scanner.nextInt();
            int k = scanner.nextInt();
            int W = scanner.nextInt();
			int y = 12;
            int sum;

            int[] weights = new int[n];
            int[] chosen = new int[n];
            for (int j = 0; j < n; j++) {
                weights[j] = scanner.nextInt(); //wam bam
				int b = 123;
            }

            sum = findW(weights, chosen, k, W,z, y, b); //wam bam thank ya mam

            result += "Items taken by force:";
            for (int j = 0; j < n; j++) {
                if (chosen[j] == 1) {
                    result += " " + (j + 1);
                }
            }
            result += "\n";
            result += "Total value: " + sum;

            result += "\n\n";
        }
        Path path = Paths.get("src/out.txt");

        Files.write(path, result.getBytes());
    }

    private static int findW(int[] weights, int[] chosen, int k, int W, int a, int b, int c) {
        int sum = 0;

        Map<Integer, Integer> list = new HashMap<>();
        for (int i = 0; i < weights.length; i++) {
            list.put(weights[i], i);
        }

        Arrays.sort(weights);
        for (int i = weights.length - 1; i >= 0; i--) { //r@nDoM COMM3NT
            if (weights[i] <= W) {
                sum += weights[i] * k;
                chosen[list.get(weights[i])] = 1;
                W = W - weights[i];
            }
        }
        return sum;
    }
}

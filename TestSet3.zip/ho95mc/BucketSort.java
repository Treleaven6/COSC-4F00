//ho95mc

import java.util.Scanner;
import java.io.*;

public class BucketSort {
	
	File src;
	Bucket[] index;
	
	public BucketSort ( double n ) {
		
		src = new File("Input.txt");
		index = new Bucket[(int)Math.pow(2,n)];
		
		
		start(src);
		parseArray(index);
		
	}
	
	public void start(File src) {
		try {
			
			Scanner in = new Scanner(src);
			int y = 0;
			
			while (in.hasNext()) {
				
				//Read and format input strings.
				String s = in.next();
				s = s.replaceAll("[^a-zA-Z]", "");
				s = s.toLowerCase();
				if (s.equals("")) {s = in.next();}
				
				//Initialize first bucket.
				if (y == 0) {
					
					Bucket first = new Bucket(null,5);
					index[0] = first;
					
					for (int j=1;j<index.length;j++) {
						index[j] = index[0];
					}
					y++;
				} 
				
				if (exists(index,s)) {
					
					incCount(index,s);
					System.out.println("INCREMENTED: "+s);
					
				} else {
										
					Node n = new Node (s,1);
					String hash = fun(n.data);
					String key = "";
					
					for (int j=0;j<(int)(Math.log(index.length)/Math.log(2));j++) {
						key += Character.toString(hash.charAt(j));
					}
					
					//The appropriate size prefix we are considering.
					int iKey = Integer.parseInt(key,2);
					
					if (index[iKey].canInsert()) { 
						
						index[iKey].bucketAdd(n);
						System.out.println("INSERT AT "+iKey+": "+n.data+", "+fun(n.data));
						
					} else {
						
						if (canDivide(index,iKey)) {
							
							divideBucket(index,iKey); 
							index[iKey+findSpare(index,iKey)].bucketAdd(n);
							System.out.println("INSERT AT "+iKey+": "+n.data+", "+fun(n.data));
							
						} else {
							
							System.out.print("CANNOT DIVIDE, EXTENDING INDEX: "+index.length);
							extendIndex();
							System.out.println(" TO "+index.length);
							key = "";
							
							for (int j=0;j<(int)(Math.log(index.length) / Math.log(2));j++) {
								key += Character.toString(hash.charAt(j));
							}
							
							//New index given from prefix
							iKey = Integer.parseInt(key,2);
							
							if (canDivide(index,iKey)) {
								
								divideBucket(index,iKey);
								
								if (index[iKey].canInsert()) {
									
									index[iKey+findSpare(index,iKey)].bucketAdd(n);
									System.out.println("INSERT AT "+iKey+": "+n.data+", "+fun(n.data));
									
								} else {
									//Should not reach this point.
									System.out.println("He's dead, Jim.");
								}
							}
						} 
					}
				}
			}
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
	
	/* Searches the array and every buckets contents. Removes 
	 * words that start with a vowel. Checks to see if a merge 
	 * must take place or not afterwards to ensure that neighbouring
	 * buckets are never empty.
	 * 
	 * @param b		The main array of buckets.
	 */ 
	public void removeVowels(Bucket[] b) {
		for (int i=0;i<b.length;i++) {
			for (int j=0;j<b[i].bucketSize();j++) {
				if (b[i].list[j] != null) {
					String a = b[i].list[j].data;
					if ((a.charAt(0)=='a')||(a.charAt(0)=='e')||(a.charAt(0)=='i')||(a.charAt(0)=='o')||(a.charAt(0)=='u')) {
						b[i].bucketRemove(a);
					}	
				}
			}
			mergeCheck(b);
		}
	}
	
	/* Increments the "count" attribute of a Node
	 * containing String s in Bucket[] b
	 * 
	 * @param b		The main array of buckets
	 * @param s		The string in question.
	 */ 
	public void incCount (Bucket[] b, String s) { 
		Bucket t1 = b[findIndex(b,s)];
		Node t2 = t1.findString(s);
		t2.count++;
	}
	
	/* Increases the length of the main array by 2^n+1 size.
	 * Reassigns the strings which have already been parsed 
	 * to the new bucket.
	 * 
	 * @return index 	The extended index.
	 */ 
	public Bucket[] extendIndex () {
		Bucket[] temp = index;
		index = new Bucket[(int)Math.pow(2,(int)(Math.log(index.length)/Math.log(2))+1)];
		reassignIndex(temp,index);
		return index;
	}

	/* Takes the buckets containing strings which have already
	 * been parsed and will relocate them in the extended index.
	 * 
	 * @param a		The original index.
	 * @param b 	The extended index.
	 */ 
	public void reassignIndex (Bucket[] a, Bucket[] b) {
		
		int n = ((int)(Math.log(a.length) / Math.log(2)));
		int m = ((int)(Math.log(b.length) / Math.log(2)));
		
		for (int i=0;i<a.length;i++) {
			
			String str = Integer.toBinaryString(i);
			StringBuffer buf = new StringBuffer(str);
			
			while ( buf.length() < n ) {
				buf.insert(0,'0');
			}
			
			str = buf.toString();
			
			for (int j=0;j<b.length;j++) {
				
				String ptr = Integer.toBinaryString(j);
				buf = new StringBuffer(ptr);
				
				while ( buf.length() < m ) {
					buf.insert(0,'0');
				}
				
				ptr = buf.toString();

				if (ptr.startsWith(str)) {
					
					b[j] = a[i];
				}
			}
		}
	}
	
	/* Checks neighbouring buckets to see if they contain few 
	 * enough elements to meet the conditions of merging. 
	 * 
	 * @param b 	The main array of buckets.
	 * @param i 	The index we are checking.
	 * @return 		The relative index we can merge with. 0 if none.
	 */ 
	public int canMerge ( Bucket[] b, int i ) {
		if (b[i].bucketSize() <= ((b[i].size) / 2)) {
			if (i-1 != -1) {
				if (b[i-1] != null) {
					if (b[i].bucketSize() <= b[i].size / 2) {
						if (b[i-1].bucketSize() <= (b[i-1].size / 2)) {
							return -1;
						}
						if (b[i+1].bucketSize() <= (b[i+1].size / 2)) {
							return 1;
						}
					}
				}	
			}
		}
		return 0;
	}
	
	/* Merges two provided buckets, joining their elements 
	 * into one larger bucket.
	 * 
	 * @param a		The first bucket we will merge.
	 * @param b		The second bucket we will merge.
	 */ 
	public void mergeBucket ( Bucket a, Bucket b ) {
		for (int i=0;i<a.bucketSize();i++) {
			if (a.list[i] != null) {
				Node temp = a.list[i];
				b.bucketAdd(temp);
			}
		}
		a = b;
	}
	
	/* Searches the entire index for the merge condition. 
	 * Will merge if it meets the condition at any point.
	 * 
	 * @param b		The main array of buckets.
	 */ 
	public void mergeCheck ( Bucket[] b) {
		for (int i=0;i<b.length;i++) {
			if (canMerge(b,i) != 0) {
				System.out.println("MERGING BUCKETS: "+i+", "+(i+canMerge(b,i)));
				mergeBucket(b[i],b[i+canMerge(b,i)]);
			}
		}
	}
	
	/* If any of a given bucket's neighbours are equal 
	 * to that bucket, or to it's neighbors it is considered
	 * "spare" and can be assigned it's own bucket through
	 * division.
	 * 
	 * @param b 	The main array of buckets.
	 * @param i 	The index of the array.
	 * @return 		true if any neighbours match, false otherwise.
	 */
	public boolean canDivide ( Bucket[] b, int i ) {
		if (i-1 != -1) {
			if (b[i-1] != null) {
				if (b[i] == b[i-1]) {
					return true;
				}
				if (i-2 != -1) {
					if (b[i-2] != null) {
						if (b[i-1] == b[i-2]) {
							return true;
						}
					}
				}
			}
		}
		if (i+1 < b.length) {
			if (b[i+1] != null) {
				if (b[i] == b[i+1]) {
					return true;
				}
				if (i+2 < b.length) {
					if (b[i+2] != null) {
						if (b[i+1] == b[i+2]) {
							return true;
						}
					}
				}
			}
		}
		return false;
	}
	
	/* Locates the relative index of which neighbour 
	 * is "spare", sharing a pointer with it's neighbor.
	 * 
	 * @param b 	The main array of buckets.
	 * @param i		The index of the array.
	 * @return 		The relative "spare" neighbour index
	 */ 
	public int findSpare ( Bucket[] b, int i ) {
		if (i-1 != -1) {
			if (b[i-1] != null) {
				if (b[i] == b[i-1]) {
					return -1;
				}
			}
		}
		if (i+1 < b.length) {
			if (b[i+1] != null) {
				if (b[i] == b[i+1]) {
					return 1;
				}
			}
		}
		if (i-2 > -1) {
			if (b[i-2] != null) {
				if (b[i-2] == b[i-1]) {
					return -1;
				}
			}
		}
		if (i+2 < b.length) {
			if (b[i+2] != null) {
				if (b[i+2] == b[i+1]) {
					return 1;
				}
			}
		}
		return 0;
	}
	
	/* Divides the given bucket after locating it's spare. Copies
	 * all values into the spare bucket then removes those that 
	 * don't match it's bucket's prefix.
	 * 
	 * @param b 	The main array of buckets.
	 * @param i		The index of the array.
	 */ 
	public void divideBucket ( Bucket[] b, int i ) {
		System.out.println("DIVIDING BUCKET "+i);
		Bucket temp = new Bucket(null,5);
		
		for (int y=0;y<b[i].size;y++) {
			temp.list[y] = b[i].list[y];
		}
		
		int x = i + findSpare(b,i);
		
		if (x == i) {
			System.out.println("ERROR DIVIDING: NO SPARE BUCKETS");
		}
		
		b[x] = temp;
		correctIndex(b[x], x);
		correctIndex(b[i], i); 
	}
	

	private void correctIndex ( Bucket b, int i) {
		String str = Integer.toBinaryString(i);
		StringBuffer buf = new StringBuffer(str);
		
		while (buf.length() < (int)(Math.log(index.length)/Math.log(2))) {
			buf.insert(0,'0');
		}
		
		String out = buf.toString();
		System.out.println(" ");
		System.out.println("CORRECTING INDEX "+out);
		int j=0;
		
		while (j<b.bucketSize()) {
			
			String temp = fun(b.list[j].data);
			String qtr = "";
			
			for (int k=0;k<(int)(Math.log(index.length) / Math.log(2));k++) {
				qtr += Character.toString(temp.charAt(k));
			}

			if (qtr.equals(out) == true || out.startsWith(qtr) == true) {
				j++;
			} else {
				System.out.println("REMOVING "+"w: "+b.list[j].data+", "+fun(b.list[j].data)+" FROM BUCKET "+i);
				b.bucketRemove(b.list[j].data);
			}
		}
		System.out.println(" ");
	} 
	

	private void parseArray (Bucket[] b) {
		int ctr = 0;
		System.out.println(" ");
		System.out.println("----------Printing Index---------");
		System.out.println("Index Length: "+b.length);
		for (int i=0;i<b.length;i++) {
			if (i+2 < b.length) {
				if (b[i] == b[i+1] || b[i] == b[i+2] ) {
					ctr++;
				}
			}
			String str = Integer.toBinaryString(i);
			System.out.println("Bucket Index: "+str+", Bucket Size: "+b[i].bucketSize());
			for (int j=0;j<b[i].bucketSize();j++) {
				if (b[i].list[j] != null) {
					System.out.println(b[i].list[j].data+" ("+b[i].list[j].count+") :: "+fun(b[i].list[j].data));
				}
			}
			System.out.println(" ");
		}
		System.out.println("Buckets: "+ctr);
	}
	

	private int findIndex ( Bucket[] b, String s ) {
		for (int i=0;i<b.length;i++) {
			for (int j=0;j<b[i].bucketSize();j++) {
				if (b[i].list[j].data.equals(s)) {
					return i;
				}
			}
		}
		return -1;
	}
	
	private boolean exists ( Bucket[] b, String s ) { //**
		for (int i=0;i<b.length;i++) {
			if (b[i] != null) {
				for (int j=0;j<b[i].length;j++) {
					
					if (b[i].list[j] != null) {
						if ( b[i].list[j].data.equals(s)) {
							return true;
						}
					}
				}
			}
		}
		return false;
	}
	
	/* Converts a string into a 10 bit pattern
	 * 
	 * @param s		The string to be converted.
	 * @return t	The 10 bit representation of String s
	 */ 
	private String fun (String s) {
        double PI=3.141592653;   
        double sum=0;
        char c;
        int l;
        int remainder;
        String t="";
            
        for (int i=0; i<s.length();i++)    {
            c=s.charAt(i);
            sum+=PI*(i+1)*Character.valueOf(c);    
        }
        sum = sum*6749;
        l=(int) sum;
        for (int i=0;i<10;i++){
            remainder = l%2;
            l=l/2; 
            t = t + remainder;
        }
        return t;    
    }
    
	public static void main (String args[]) {
		
		BucketSort bs = new BucketSort(1);
		
	}	
}
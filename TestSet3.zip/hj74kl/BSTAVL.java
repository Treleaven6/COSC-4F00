//hj74kl

import java.util.Scanner;
import java.io.*;



public class BSTAVL {

	File src;
	Node p;
	Node q;
	
	public BSTAVL ( ) {
		
	src = new File("Input.txt");
	p = new Node(null,1,1,null,null);
	q = new Node(null,1,1,null,null);
	System.out.println("Enter 'FIRST' for standard tree insertion.");
	System.out.println("Then use 'SECOND' for removal of words starting with vowels.");	
	
	//Order of commands: FIRST, PRINTP, PRINTQ, SECOND, PRINTP, PRINTQ, EXIT
	
	Scanner first = new Scanner(System.in);
	while (first.hasNext()) {
	if (first.next().equals("FIRST")) {
		try {
		Scanner sc = new Scanner(src);
		while (sc.hasNext()) {
			String s = sc.next();
			
			//Filters punctuation before inserting into the tree.
			String punct = "',./?;()-:";
		for (int i=0; i<s.length();i++) {
			
			String temp = Character.toString(s.charAt(i));
			if (temp.equals(Character.toString(punct.charAt(0)))) {
				s = s.replace("'","");
			}
			if (temp.equals(Character.toString(punct.charAt(1)))) {
				s = s.replace(",","");
			}
			if (temp.equals(Character.toString(punct.charAt(2)))) {
				s = s.replace(".","");
			}
			if (temp.equals(Character.toString(punct.charAt(3)))) {
				s = s.replace("/","");
			}
			if (temp.equals(Character.toString(punct.charAt(4)))) {
				s = s.replace("?","");
			}
			if (temp.equals(Character.toString(punct.charAt(5)))) {
				s = s.replace(";","");
			}
			if (temp.equals(Character.toString(punct.charAt(6)))) {
				s = s.replace("(","");
			}
			if (temp.equals(Character.toString(punct.charAt(7)))) {
				s = s.replace(")","");
			}
			if (temp.equals(Character.toString(punct.charAt(8)))) {
				s = s.replace("-","");
			}
			if (temp.equals(Character.toString(punct.charAt(9)))) {
				s = s.replace(":","");
			}
			
		}
			System.out.print(s+" ");
			insertP(s,p);
			insertQ(s,q);
		} //fills both trees with input text
		
		System.out.println(" ");
		System.out.println("Enter 'PRINTP' then 'PRINTQ' to see an In Order traversal of each tree.");
		System.out.println("Enter 'SECOND' to remove the vowels.");
		System.out.println("Enter 'EXIT' when finished.");
		
	} catch (FileNotFoundException e) {
		System.out.println(e.getMessage());
		e.printStackTrace();
	}
	
	Scanner input = new Scanner(System.in);
	while (input.hasNext()) {
		String s = input.next();
		
		//Presents keywords to manipulate the scanner	
			if (s.equals("EXIT")) {
				input.close();
			}
			if (s.equals("PRINTP")) {
				System.out.println("In Order of Tree P: ");
				inOrder(p);
				System.out.println(" ");
				System.out.println("Internal Path length: " + intPathLength(p,0));
				System.out.println("Average Path Length: " + intPathLength(p,0)/numNodes(q));
				System.out.println(" ");
			} 
			if (s.equals("PRINTQ")) {
				System.out.println("In Order of Tree Q: ");
				inOrder(p);
				System.out.println(" ");
				System.out.println("Internal Path length: " + intPathLength(q,0));
				System.out.println("Average Path Length: " + intPathLength(q,0)/numNodes(q));
				System.out.println(" ");
			}
			
			if (s.equals("SECOND")) {
				try {
					Scanner sc = new Scanner(src);
					while (sc.hasNext()) {
					String s2 = sc.next();
					
					String punct = "',./?;()-:";
			for (int i=0; i<s2.length();i++) {
			
			String temp = Character.toString(s2.charAt(i));
			if (temp.equals(Character.toString(punct.charAt(0)))) {
				s2 = s2.replace("'","");
			}
			if (temp.equals(Character.toString(punct.charAt(1)))) {
				s2 = s2.replace(",","");
			}
			if (temp.equals(Character.toString(punct.charAt(2)))) {
				s2 = s2.replace(".","");
			}
			if (temp.equals(Character.toString(punct.charAt(3)))) {
				s2 = s2.replace("/","");
			}
			if (temp.equals(Character.toString(punct.charAt(4)))) {
				s2 = s2.replace("?","");
			}
			if (temp.equals(Character.toString(punct.charAt(5)))) {
				s2 = s2.replace(";","");
			}
			if (temp.equals(Character.toString(punct.charAt(6)))) {
				s2 = s2.replace("(","");
			}
			if (temp.equals(Character.toString(punct.charAt(7)))) {
				s2 = s2.replace(")","");
			}
			if (temp.equals(Character.toString(punct.charAt(8)))) {
				s2 = s2.replace("-","");
			}
			if (temp.equals(Character.toString(punct.charAt(9)))) {
				s2 = s2.replace(":","");
			}
		}
						if (vowelCheck(s2) == true) {
							System.out.print(s2+" ");
						} else {
							delete(s2,p);
							delete(s2,q);
						}
					} //cycles through the input, deletes nodes that starts with vowels.
		
		System.out.println(" ");
		System.out.println("Enter 'PRINTP' then 'PRINTQ' to see an In Order traversal of each tree.");
		System.out.println("Enter 'EXIT' when finished.");
		
			} catch (FileNotFoundException e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
	
	Scanner input2 = new Scanner(System.in);
	while (input.hasNext()) {
		String s2 = input.next();
		
		//Presents keywords to manipulate the scanner	
			if (s2.equals("EXIT")) {
				input2.close();
			}
			if (s2.equals("PRINTP")) {
				System.out.println("In Order of Tree P: ");
				inOrder(p);
				System.out.println(" ");
				System.out.println("Internal Path length: " + intPathLength(p,0));
				System.out.println("Average Path Length: " + intPathLength(p,0)/numNodes(q));
				System.out.println(" ");
			} 
			if (s2.equals("PRINTQ")) {
				System.out.println("In Order of Tree Q: ");
				inOrder(p);
				System.out.println(" ");
				System.out.println("Internal Path length: " + intPathLength(q,0));
				System.out.println("Average Path Length: " + intPathLength(q,0)/numNodes(q));
				System.out.println(" ");
			 }
		  } //input.hasNext(); - End of keywords
	    } //'SECOND'
	  } //input.hasNext();
	} //'FIRST'
  } //first.hasNext();
}// constructor

// --- All methods and functions below. --- \\

	//Performs an insert into the P tree.
	public void insertP ( String a, Node n ) { //**
		if (n.data == null) {
			n.data = a;
		}
		 if (a.compareTo(n.data) < 0) {
			 if (n.leftChild == null) {
				 n.leftChild = new Node(a,1,1,null,null);
			 } else {
				 insertP(a,n.leftChild);
			 }
		 } else if (a.compareTo(n.data) > 0) {
			 if (n.rightChild == null) {
				 n.rightChild = new Node (a,1,1,null,null);
			 } else {
				 insertP(a,n.rightChild);
			 }
		 } else {
			n.count++; 
		 }
    } //insertP
    
    /* Performs an insert into the Q tree, balancing and 
     * ensuring AVL compliance afterwards.
     */ 
    public Node insertQ (String a, Node n) {//**
		if (n.data == null) {
			n.data = a;
		}
			if (a.compareTo(n.data) < 0) {
				if (n.leftChild == null) {
					n.leftChild = new Node(a,1,1,null,null);
					return n.leftChild;
				} else {
				insertQ(a,n.leftChild);
				/* If the insert unbalances the tree, check if it is 
				 * now right heavy or left heavy on the new node.
				 */
				if (isAVL(n) == false) { 
					if (a.compareTo(n.leftChild.data) < 0) {
						n = singleRight(n);
						return n;
					} else {				
						dRotateRight(n);
						return n;
					}
			  } else {
				setHeight(n);
			}
		}
		} else if (a.compareTo(n.data) > 0) {
			if (n.rightChild == null) {
				n.rightChild = new Node (a,1,1,null,null);
				return n.rightChild;
			} else {
				insertQ(a,n.rightChild);
				/* Similar to above, checking if the tree is now 
				 * right heavy or left heavy due to the insert.
				 */
			if (isAVL(n) == false) {
				if (a.compareTo(n.rightChild.data) > 0) {
					n = singleLeft(n);
					return n;
				} else {
					n = dRotateLeft(n);
					return n;
				}
			} else {
				setHeight(n);
			}
			}
		} else {
			n.count++;
		}
		return n;
	} //insertQ
    
    //Deletes from the tree.
    public Node delete (String a, Node n) { //**
		if (n == null) {
			return n;
		}
		if (a.compareTo(n.data) < 0) {
			n.leftChild = delete(a, n.leftChild);
		} else if (a.compareTo(n.data) > 0) {
			n.rightChild = delete(a, n.rightChild);
		} else if (n.leftChild != null && n.rightChild != null) {
			n.data = successor(n,p).data;
			n.rightChild = delete(n.data,n.rightChild);
		} else {
			if (n.leftChild != null) {
				n = n.leftChild;
			} else {
				n = n.rightChild;
			}
			return n;
		}
		return n;
	} //delete
	
    //Finds the successor of any given node 
    //in an In Order traversal
    public Node successor (Node n, Node root) { //**
	    Node ptr;
	    if (n.rightChild == null) {
			ptr = findParentOf(n,root);
			while (ptr.data.compareTo(n.data) <= 0) {
				ptr = findParentOf(ptr,root);
			}
			return ptr;
		} else {
			ptr = n.rightChild;
			if (ptr.leftChild == null) {
				return ptr;
			} else {
				while (ptr.leftChild != null)  {
					ptr = ptr.leftChild;
				}
				return ptr;
			}
	    }
	} //successor
	
	public boolean vowelCheck (String s) {
		String chars = "aeiouAEIOU";
		String temp = Character.toString(s.charAt(0));
		
		if (  temp.equals(Character.toString(chars.charAt(0))) || temp.equals(Character.toString(chars.charAt(1))) 
		   || temp.equals(Character.toString(chars.charAt(2))) || temp.equals(Character.toString(chars.charAt(3)))
		   || temp.equals(Character.toString(chars.charAt(4))) || temp.equals(Character.toString(chars.charAt(5))) 
		   || temp.equals(Character.toString(chars.charAt(6))) || temp.equals(Character.toString(chars.charAt(7)))
		   || temp.equals(Character.toString(chars.charAt(8))) || temp.equals(Character.toString(chars.charAt(9))) ) {
				return false;
			} else {
				return true;
			}
	} //vowelCheck
	
	//Uses two pointers to find the parent of a specific node.
	//Similar to find() but second pointer lags behind first.
	public Node findParentOf (Node n, Node root) { //**
		Node ptr = root; //tail
		Node qtr = root; //head
		
		while (n.data.compareTo(qtr.data) != 0) {
			if (n.data.compareTo(qtr.data) < 0) {
				ptr = qtr;
				qtr = qtr.leftChild;
			} else {
				ptr = qtr;
				qtr = qtr.rightChild;
			}
			
		}
		return ptr;
	} //findParentOf
	
    //Tests for key equality between Nodes until it has found 
    //the right one.
    public Node find ( String a, Node n ) { //**
		Node ptr = n;
		if (n.data == null) {
			return null;
		} else {
			while (a.compareTo(ptr.data) != 0) {
				if (a.compareTo(ptr.data) < 0) {
					ptr = ptr.leftChild;
				} else {
					ptr = ptr.rightChild;
				}
			}
			}
			return ptr;
    } //find
    
    //Returns the number of nodes starting at root n.
    public int numNodes(Node n) { //**
		if (n == null) {
			return 0;
		} else {
			return (numNodes(n.leftChild) + numNodes(n.rightChild) + 1);
		}
	} //numNodes
    
    //Performs and InOrder traversal of the tree.
    public void inOrder (Node n) { //**
		
		if (n.leftChild != null) {
		inOrder(n.leftChild);
		}
		System.out.print(n.data + "(" + n.count + ") --- ");
		if (n.rightChild != null) {
		inOrder(n.rightChild);
		}
    } //inOrder
    
    //Calculates the internal path length recursively. 
	public int intPathLength (Node n, int x) { //**
		int temp;
		if ( n == null) {
			return 0;
		}
		temp = (x + intPathLength(n.rightChild,x+1) + intPathLength(n.leftChild,x+1));
		return temp;
	} //intPathLength
    
    //True if tree is AVL compliant at root n. 
    //Recursively checks all subtrees.
    public boolean isAVL (Node n) { //** 
	
		if (n.leftChild == null && n.rightChild != null) {
			if (n.rightChild.leftChild == null && n.rightChild.rightChild == null) {
				return true;
			} else {
				return true;
			} 
		} else if (n.rightChild == null && n.leftChild != null) {
			if (n.leftChild.leftChild != null || n.leftChild.rightChild != null) {
				return false;
			} else {
				return true;
			}
			
		} else if (n.leftChild != null && n.rightChild != null) {
			if (isAVL(n.leftChild) == true && isAVL(n.rightChild) == true) {
				return true;
			} else {
				return false;
			}
		} else if (n.leftChild == null && n.rightChild == null) {
			return true;
		}
		return false;
    } //isAVL
    
    //Returns the nodes height value.
    public int findHeight (Node n) { //**
		if (n == null) {
			return -1;
		} else {
			return n.height;
		}
	} //height
	
	//Sets the height of the tree starting at root n appropriately.
	public int setHeight (Node n) {
		
		if (n.leftChild == null && n.rightChild == null) {
			n.height = 1;
			return n.height;
		} else if (n.leftChild != null && n.rightChild == null) {
			n.height = 1 + setHeight(n.leftChild);
			return n.height;
		} else if (n.leftChild == null && n.rightChild != null) {
			n.height = 1 + setHeight(n.rightChild);
			return n.height;
		} else {
			n.height = 1 + Math.max(setHeight(n.leftChild),
									setHeight(n.rightChild));
			return n.height;
		}
	} //setHeight
	
	public Node singleRight (Node b){ //**
		Node a;
		a = b.leftChild;		
		b.leftChild = a.rightChild; 	
		a.rightChild = b;		
		
		setHeight(b);
		b = a;				
		return b;

    } //singleRight
	
	public Node singleLeft (Node b) { //**
		Node a;
		a = b.rightChild;
		b.rightChild = a.leftChild;
		a.leftChild = b;
		
		setHeight(b);
		b = a;
		return b;
	
	} //singleLeft
	
	public Node dRotateRight (Node c) { //**
		c.leftChild = singleLeft(c.leftChild);
		c = singleRight(c);
		return c;
      
	} //dRotateRight
	
	public Node dRotateLeft (Node d) { //**
		d.rightChild = singleRight(d.rightChild);
		d = singleLeft(d);
		return d;
       
	} //dRotateLeft
	
    public static void main(String[] args) {
		BSTAVL x = new BSTAVL();
    } //main
} //BSTAVL